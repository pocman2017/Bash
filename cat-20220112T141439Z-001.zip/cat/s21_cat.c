#include "s21_cat.h"

int main(int argc, char *argv[]) {
  CatFlags.opt_B = 0;
  CatFlags.opt_V = 0;
  CatFlags.opt_E = 0;
  CatFlags.opt_Ebig = 0;
  CatFlags.opt_N = 0;
  CatFlags.opt_S = 0;
  CatFlags.opt_T = 0;
  CatFlags.opt_Tbig = 0;
  CatFlags.error = 0;
  int flag = 0;
  if (argc > 1) {
    FlagParser(argc, argv);
    if (OpenFile(argc, argv) == 1) flag = 1;
  } else {
    flag = 1;
  }
  return flag;
}
void FlagParser(int argc, char *argv[]) {
  int count = 0;
  for (count = 1; count < argc; count++) {
    if (argv[count][0] == '-') {
      if (argv[count][1] != '-') {
        for (int i = 1; i < (int)strlen(argv[count]); i++) {
          if (argv[count][i] == 'b')
            CatFlags.opt_B = 1;
          else if (argv[count][i] == 'v')
            CatFlags.opt_V = 1;
          else if (argv[count][i] == 'e')
            CatFlags.opt_E = 1;
          else if (argv[count][i] == 'E')
            CatFlags.opt_Ebig = 1;
          else if (argv[count][i] == 'n')
            CatFlags.opt_N = 1;
          else if (argv[count][i] == 's')
            CatFlags.opt_S = 1;
          else if (argv[count][i] == 't')
            CatFlags.opt_T = 1;
          else if (argv[count][i] == 'T')
            CatFlags.opt_Tbig = 1;
          else
            CatFlags.error = 1;
        }
      } else {
        if (strcmp(argv[count], "--number-nonblank") == 0) CatFlags.opt_B = 1;
        if (strcmp(argv[count], "--show-nonprinting") == 0) CatFlags.opt_V = 1;
        if (strcmp(argv[count], "--show-ends") == 0) CatFlags.opt_Ebig = 1;
        if (strcmp(argv[count], "--number") == 0) CatFlags.opt_N = 1;
        if (strcmp(argv[count], "--squeeze-blank") == 0) CatFlags.opt_S = 1;
        if (strcmp(argv[count], "--show-tabs") == 0) CatFlags.opt_Tbig = 1;
      }
    }
  }
}

int OpenFile(int argc, char *argv[]) {
  int flag = 0;
  FILE *file = NULL;
  if (CatFlags.error != 1) {
    for (int count = 1; count < argc; count++) {
      if (argv[count][0] != '-') {
        if ((file = fopen(argv[count], "r")) != NULL) {
          PrepareForPrintFile(file);
          fclose(file);
        } else {
          printf("s21_cat: %s: No such file or directory\n", argv[count]);
          flag = 1;
          break;
        }
      }
    }
  } else {
    printf("cat: invalid option\n Try 'cat --help' for more information\n");
    flag = 1;
  }
  return flag;
}

void PrepareForPrintFile(FILE *file) {
  int c = 0;
  if ((c = getc(file)) != EOF) {
    int old_c = c;
    // first output for -T
    if (CatFlags.opt_Tbig && c == '\t') {
      printf("^");
      old_c = 73;
    }
    // first output fo flag -n without -b
    int number = 1;
    if (CatFlags.opt_N && !CatFlags.opt_B) {
      printf("%6d\t", number++);
    }
    // first output for flag -b with or without -n
    if ((CatFlags.opt_N && CatFlags.opt_B) || (CatFlags.opt_B)) {
      if (c != '\n') printf("%6d\t", number++);
    }
    // first output for flag -E
    if (CatFlags.opt_Ebig) {
      if (c == '\n') printf("%c", 36);
    }
    int count_empty_strokes = 0;
    while ((c = getc(file)) != EOF) {
      if (CatFlags.opt_S) {
        if (c == '\n' && old_c == '\n') {
          while (c == '\n') {
            c = fgetc(file);
            count_empty_strokes++;
          }
          if (count_empty_strokes >= 1) {
            fseek(file, -1, SEEK_CUR);
            c = '\n';
          }
          count_empty_strokes = 0;
        }
      }
      PrintFile(old_c);
#ifdef __linux__
      if (CatFlags.opt_N && !CatFlags.opt_B) {
        if (old_c == '\n') printf("%6d\t", number++);
      }
      if ((CatFlags.opt_N && CatFlags.opt_B) || (CatFlags.opt_B)) {
        if (old_c == '\n' && c != '\n') printf("%6d\t", number++);
      }
#elif __APPLE__
      int catch_vet = 0;
      if (CatFlags.opt_V || CatFlags.opt_E || CatFlags.opt_T) {
        catch_vet = 1;
      }
      if (CatFlags.opt_N && !CatFlags.opt_B && !catch_vet) {
        if (old_c == '\n') printf("%6d\t", number++);
      }
      if (CatFlags.opt_N && !CatFlags.opt_B && catch_vet) {
        if (old_c == '\n' || old_c == 138) printf("%6d\t", number++);
      }
      if (((CatFlags.opt_N && CatFlags.opt_B) || (CatFlags.opt_B)) &&
          !catch_vet) {
        if (old_c == '\n' && c != '\n') printf("%6d\t", number++);
      }
      if (((CatFlags.opt_N && CatFlags.opt_B) || (CatFlags.opt_B)) &&
          catch_vet) {
        if ((old_c == '\n' || old_c == 138) && c != '\n')
          printf("%6d\t", number++);
      }
#endif
      if (CatFlags.opt_Ebig) {
        if (c == '\n') printf("%c", 36);
      }
      if (CatFlags.opt_Tbig) {
        if (c == '\t') {
          c = 73;
          printf("%c", 94);
        }
      }
      old_c = c;
    }
    PrintFile(old_c);
  }
}

void PrintFile(int symbol) {
  if (CatFlags.opt_V || CatFlags.opt_E || CatFlags.opt_T) {
    if (symbol == '\n' && CatFlags.opt_E == 1) printf("%c", 36);
    if (symbol == '\t' && CatFlags.opt_T) {
      symbol = 73;
      printf("%c", 94);
    }
    if (symbol >= 0 && symbol <= 31 && symbol != 9 && symbol != 10)
      printf("^%c", symbol + 64);
    else if (symbol == 127)
      printf("^%c", symbol - 64);
    else if (symbol >= 128 && symbol <= 159)
      printf("M-^%c", symbol - 64);

#ifdef __linux__
    else if (symbol >= 160 && symbol < 255)
      printf("M-%c", symbol - 128);
    else if (symbol == 255)
      printf("M-^%c", symbol - 192);
#endif
    else
      fprintf(stdout, "%c", symbol);
  } else {
    fprintf(stdout, "%c", symbol);
  }
}
