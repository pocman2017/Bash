#ifndef SRC_CAT_S21_CAT_H_
#define SRC_CAT_S21_CAT_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Options {
  int opt_B;
  int opt_V;
  int opt_E;
  int opt_Ebig;
  int opt_N;
  int opt_S;
  int opt_T;
  int opt_Tbig;
  int error;
} CatFlags;

void FlagParser(int argc, char *argv[]);
int OpenFile(int argc, char *argv[]);
void PrepareForPrintFile(FILE *file);
void PrintFile(int symbol);

#endif  // SRC_CAT_S21_CAT_H_
