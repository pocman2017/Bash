#include "s21_grep.h"

int main(int argc, char *argv[]) {
  GrepFlags.opt_E = 0, GrepFlags.opt_I = 0, GrepFlags.opt_V = 0,
  GrepFlags.opt_C = 0, GrepFlags.opt_L = 0, GrepFlags.opt_N = 0,
  GrepFlags.opt_H = 0, GrepFlags.opt_S = 0, GrepFlags.opt_F = 0,
  GrepFlags.opt_O = 0, GrepFlags.error = 0, GrepFlags.number_files = 0;
  memset(GrepFlags.pattern, 0, N_MAX_PATTERN);
  int flag = 0;
  if (argc > 1) {
    FlagParser(argc, argv);
    if (OpenFile(argc, argv) == 1) flag = 1;
  } else {
    flag = 1;
  }
  return flag;
}

void FlagParser(int argc, char *argv[]) {
  int count = 0, count_flags = 0, count_patterns = 0;
  for (count = 1; count < argc; count++) {
    if (argv[count][0] == '-') {
      if (argv[count][1] != '-') {
        for (int i = 1; i < (int)strlen(argv[count]); i++) {
          if (argv[count][i] == 'e')
            GrepFlags.opt_E = 1;
          else if (argv[count][i] == 'i')
            GrepFlags.opt_I = 1;
          else if (argv[count][i] == 'v')
            GrepFlags.opt_V = 1;
          else if (argv[count][i] == 'c')
            GrepFlags.opt_C = 1;
          else if (argv[count][i] == 'l')
            GrepFlags.opt_L = 1;
          else if (argv[count][i] == 'n')
            GrepFlags.opt_N = 1;
          else if (argv[count][i] == 'h')
            GrepFlags.opt_H = 1;
          else if (argv[count][i] == 's')
            GrepFlags.opt_S = 1;
          else if (argv[count][i] == 'f')
            GrepFlags.opt_F = 1;
          else if (argv[count][i] == 'o')
            GrepFlags.opt_O = 1;
          else
            GrepFlags.error = 1;
        }
      } else {
        if (strcmp(argv[count], "--ignore-case") == 0) GrepFlags.opt_I = 1;
        if (strcmp(argv[count], "--invert-match") == 0) GrepFlags.opt_V = 1;
        if (strcmp(argv[count], "--count") == 0) GrepFlags.opt_C = 1;
        if (strcmp(argv[count], "--files-with-matches") == 0)
          GrepFlags.opt_L = 1;
        if (strcmp(argv[count], "--line-number") == 0) GrepFlags.opt_N = 1;
        if (strcmp(argv[count], "--no-filename") == 0) GrepFlags.opt_H = 1;
        if (strcmp(argv[count], "--no-messages") == 0) GrepFlags.opt_S = 1;
        if (strcmp(argv[count], "--only-matching") == 0) GrepFlags.opt_O = 1;
      }
      count_flags++;
      count_patterns++;
      int length_of_buffer = (int)strlen(GrepFlags.pattern);
      snprintf(GrepFlags.pattern + length_of_buffer, sizeof(GrepFlags.pattern),
               "%s", argv[count + 1]);

    } else if (count_flags == 0) {
      snprintf(GrepFlags.pattern, sizeof(GrepFlags.pattern), "%s", argv[1]);
      count_patterns = 1;
    }
  }
  GrepFlags.number_files = argc - 1 - count_flags - count_patterns;
}

int OpenFile(int argc, char *argv[]) {
  int flag = 0;
  const char *filename = NULL;
  FILE *file = NULL;
  if (GrepFlags.error != 1) {
    for (int count = argc - GrepFlags.number_files; count < argc; count++) {
      if ((file = fopen(argv[count], "rt")) != NULL) {
        filename = argv[count];
        if (PrepareForOutput(file, filename) == 1) break;
        fclose(file);
      } else if (!GrepFlags.opt_S) {
        fprintf(stderr, "s21_grep: %s: No such file or directory\n",
                argv[count]);
        flag = 1;
        break;
      }
    }
  } else if (!GrepFlags.opt_S) {
    fprintf(stderr, "grep: invalid option\n");
    flag = 1;
  }
  return flag;
}

int PrepareForOutput(FILE *file, const char *filename) {
  int flag = 0;
  char read_str[N_MAX_STR] = "";
  int regcomp_flag = 0;
  int count_strokes_number = 0;
  int count_success_find = 0;
  regex_t regexpression;
  if (GrepFlags.opt_I) regcomp_flag = REG_ICASE;
  regcomp(&regexpression, GrepFlags.pattern, regcomp_flag);
  while (fgets(read_str, sizeof(read_str), file)) {
    count_strokes_number++;
    int success_regexec = regexec(&regexpression, read_str, 0, NULL, 0);
    if ((!success_regexec && !GrepFlags.opt_L) ||
        (success_regexec == REG_NOMATCH && GrepFlags.opt_V)) {
      count_success_find++;
      OutputResult(read_str, &regexpression, count_strokes_number,
                   count_success_find, filename);

    } else if (GrepFlags.opt_F) {
      if (Print_flag_F(read_str, filename) == 1) {
        flag = 1;
        break;
      }
    } else if (GrepFlags.opt_L) {
      if (!success_regexec) {
        printf("%s\n", filename);
        break;
      }
    }
  }
  if (GrepFlags.opt_C)
    (GrepFlags.number_files > 1 && !GrepFlags.opt_H)
        ? printf("%s:%d\n", filename, count_success_find)
        : printf("%d\n", count_success_find);
  regfree(&regexpression);
  return flag;
}

void OutputResult(char *read_str, regex_t *regexpression,
                  int count_strokes_number, int count_success_find,
                  const char *filename) {
  int success_regexec = 0;
  success_regexec = regexec(regexpression, read_str, 0, NULL, 0);
  if (!GrepFlags.opt_C && !GrepFlags.opt_F && !GrepFlags.opt_L) {
    if (GrepFlags.opt_V) {
      if (success_regexec == REG_NOMATCH)
        (GrepFlags.number_files > 1 && !GrepFlags.opt_H)
            ? printf("%s:%s", filename, read_str)
            : printf("%s", read_str);

    } else if (GrepFlags.opt_N) {
      (GrepFlags.number_files > 1 && !GrepFlags.opt_H)
          ? printf("%s:%d:%s", filename, count_strokes_number, read_str)
          : printf("%d:%s", count_strokes_number, read_str);
    } else if (GrepFlags.opt_O) {
      size_t nmatch = 2;
      regmatch_t temp[2];
      regoff_t length;
      success_regexec = regexec(regexpression, read_str, nmatch, temp, 0);
      char *ptr = read_str;
      while (success_regexec != REG_NOMATCH) {
        if (ptr == read_str) count_success_find++;
        length = temp[0].rm_eo - temp[0].rm_so;

        (GrepFlags.number_files > 1 && !GrepFlags.opt_H && ptr == read_str)
            ? printf("%s:%.*s\n", filename, (int)length, ptr + temp[0].rm_so)
            : printf("%.*s\n", (int)length, ptr + temp[0].rm_so);
        ptr += temp[0].rm_eo;
        success_regexec = regexec(regexpression, ptr, nmatch, temp, 0);
      }
    } else {
      (GrepFlags.number_files > 1 && !GrepFlags.opt_H)
          ? printf("%s:%s", filename, read_str)
          : printf("%s", read_str);
    }
    // if pattern was found in the last stroke without \n
    int last_char_in_stroke = (int)strlen(read_str);
    if (((!success_regexec && !GrepFlags.opt_V) ||
         (success_regexec == REG_NOMATCH && GrepFlags.opt_V)) &&
        read_str[last_char_in_stroke - 1] != '\n')
      printf("\n");
  }
}

int Print_flag_F(char *read_str, const char *filename) {
  FILE *file_pattern = NULL;
  int flag = 0;
  regex_t regexpression_from_file;

  if ((file_pattern = fopen(GrepFlags.pattern, "rt")) != NULL) {
    char read_pattern[N_MAX_STR] = "";
    while (fgets(read_pattern, sizeof(read_pattern), file_pattern)) {
      int length_of_pattern = strlen(read_pattern);
      if (read_pattern[length_of_pattern - 1] == '\n')
        read_pattern[length_of_pattern - 1] = '\0';
      regcomp(&regexpression_from_file, read_pattern, 0);
      int success_regexec =
          regexec(&regexpression_from_file, read_str, 0, NULL, 0);
      if (!success_regexec) {
        if (!GrepFlags.opt_C)
          (GrepFlags.number_files > 1 && !GrepFlags.opt_H)
              ? printf("%s:%s", filename, read_str)
              : printf("%s", read_str);
        int last_char_in_stroke = (int)strlen(read_str);
        if (read_str[last_char_in_stroke - 1] != '\n') printf("\n");
        break;
      }

      regfree(&regexpression_from_file);
    }
    fclose(file_pattern);
  } else if (!GrepFlags.opt_S) {
    fprintf(stderr, "s21_grep: %s: No such file or directory\n",
            GrepFlags.pattern);
    flag = 1;
  }
  return flag;
}
