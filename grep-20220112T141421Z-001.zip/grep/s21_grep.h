#ifndef SRC_GREP_S21_GREP_H_
#define SRC_GREP_S21_GREP_H_

#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N_MAX_PATTERN 100
#define N_MAX_STR 1024

struct Options {
  int opt_E;
  int opt_I;
  int opt_V;
  int opt_C;
  int opt_L;
  int opt_N;
  int opt_H;
  int opt_S;
  int opt_F;
  int opt_O;
  int error;
  char pattern[N_MAX_PATTERN];
  int number_files;
} GrepFlags;

void FlagParser(int argc, char *argv[]);
int OpenFile(int argc, char *argv[]);
int PrepareForOutput(FILE *file, const char *filename);
void OutputResult(char *read_str, regex_t *regexpression,
                  int count_strokes_number, int count_success_find,
                  const char *filename);
int Print_flag_F(char *read_str, const char *filename);

#endif  // SRC_GREP_S21_GREP_H_
